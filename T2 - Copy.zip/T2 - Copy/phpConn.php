<?php
    $serverName = "localhost";
    $connectionOptions = array(
        "Database" => "dbTest",
        "Uid" => "yourUserID",
        "PWD" => "yourPassword"
    );
    //Establishes the connection
    $conn = sqlsrv_connect($serverName, $connectionOptions);
    if($conn)
        echo "Connected!";


?>