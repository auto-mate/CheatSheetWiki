<html>
<head>
  <script src="https://cdn.plot.ly/plotly-latest.min.js"></script>
</head>
<body>
<?php



class barGraph {
    
    public $title               = "default";
    public $titleFontSize       = 12;
    public $titleLeftToRightPos = 0.5;
    public $titleTopToBottomPos = 0.5;

    public $legendText = "legendText";
    public $legendShow = "true";

    public $left      = 0; 
    public $top       = 0;
    public $width     = 300;
    public $height    = 300;

    public $color     =   "green";
    public $bgColor   = "#FFFFFF";
    
    public $xCsv = "'giraffes', 'orangutans', 'monkeys'";
    public $yCsv = "         1,            2,         3";

    function draw() {

        $divStyle =             "position:absolute;";
        $divStyle = $divStyle . "top:"     . $this->top    . ";";
        $divStyle = $divStyle . "left:"    . $this->left   . ";";
        $divStyle = $divStyle . "width:"   . $this->width  . ";";
        $divStyle = $divStyle . "height:"  . $this->height . ";";

        echo "<div style=\"" . $divStyle . "\" id = \"myDiv\">
        <script>
        var data = [
          {
            x: [". $this->xCsv ."],
            y: [". $this->yCsv ."],
            //text:['text.a','text.b','text.c'],
            //hovertext:['hovertext.a','hovertext.b','hovertext.c'],
            name:'"          . $this->legendText  . "',       // };
            showlegend:"     . $this->legendShow  . ",        // }
            marker:{color:'" . $this->color       ."'},            
            type: 'bar'
          }
        ];
        var layout = {plot_bgcolor: '"   . $this->bgColor             . "',
                      title:{ text:'"    . $this->title               . "', 
                            x:"          . $this->titleLeftToRightPos . ", 
                            y:"          . $this->titleTopToBottomPos . ", 
                            font:{size:" . $this->titleFontSize ."} }};
        Plotly.newPlot('myDiv', data, layout );
        </script>";
    }

}

$barGraph_01                          = new barGraph;
    $barGraph_01->title               =  "G_1";
    $barGraph_01->titleFontSize       =     16;
    $barGraph_01->titleLeftToRightPos =    0.5;
    $barGraph_01->titleTopToBottomPos =   0.65;    
    $barGraph_01->legendText          =  "New";
    $barGraph_01->legendShow          = "true";
    $barGraph_01->left                =     25;
    $barGraph_01->top                 =    250;
    $barGraph_01->width               =    250;
    $barGraph_01->height              =    250;
    $barGraph_01->xCsv                = "'cats', 'dogs', 'fish', 'cats', 'dogs', 'fish' ";
    $barGraph_01->yCsv                = "    10,      2,      3,     10,      2,       3";
    $barGraph_01->color               =  "yellow";
    $barGraph_01->bgColor             = "#0101FF";
$barGraph_01->draw();


?>


</div>
</body>
</html>