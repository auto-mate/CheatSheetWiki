<?php 
class barGraph {
    
    public $title               = "default";
    public $id                  = "";

    public $titleFontSize       = 12;
    public $titleLeftToRightPos = 0.5;
    public $titleTopToBottomPos = 0.5;

    public $xAxisFontSize = 10;
    public $yAxisFontSize = 10;

    public $legendText = "legendText";
    public $legendShow = "true";

    public $left      = 0; 
    public $top       = 0;
    public $width     = 300;
    public $height    = 300;

    public $color     =   "green";
    public $bgColor   = "#FFFFFF";
    
    public $xCsv = "'giraffes', 'orangutans', 'monkeys'";
    public $yCsv = "         1,            2,         3";

    function draw() {

        $divStyle =             "position:absolute; z-index:0; border:1px; border:solid;";
        $divStyle = $divStyle . "top:"     . $this->top    . ";";
        $divStyle = $divStyle . "left:"    . $this->left   . ";";
        $divStyle = $divStyle . "width:"   . $this->width  . ";";
        $divStyle = $divStyle . "height:"  . $this->height . ";";

        echo "<div style = \"" . $divStyle . "\" 
                      id = \"" . $this->id . "\">
              </div>
        <script>
        var data = [
          {
            x: [". $this->xCsv ."],
            y: [". $this->yCsv ."],
            //text:['text.a','text.b','text.c'],
            //hovertext:['hovertext.a','hovertext.b','hovertext.c'],
            name:'"          . $this->legendText  . "',       // };
            showlegend:"     . $this->legendShow  . ",        // }
            marker:{color:'" . $this->color       ."'},            
            type: 'bar'
          }
        ];
        var layout = {plot_bgcolor: '"   . $this->bgColor             . "',
                      margin:{l:30, r:20, t:20, b:40, pad:0},
                      yaxis:{ tickfont: { size:" . $this->yAxisFontSize . " } },
                      xaxis:{ tickfont: { size:" . $this->xAxisFontSize . " } },
                      title:{ text:'"    . $this->title               . "', 
                            x:"          . $this->titleLeftToRightPos . ", 
                            y:"          . $this->titleTopToBottomPos . ",                                
                            font:{size:" . $this->titleFontSize ."} }};
        Plotly.newPlot('" . $this->id . "', data, layout );
        </script>";
    }

}

?>
