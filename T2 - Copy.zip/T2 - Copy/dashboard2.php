<html>
<head>
  <script src="https://cdn.plot.ly/plotly-latest.min.js"></script>
</head>
<body style="background-color:darkgrey; ">
<h2   style="position:relative; 
             color:white;
             top:30px; 
             text-align:center;">Title</h2>
<?php

include_once("globals.php");
include_once("kpi.php");
include_once("barGraph.php");


$topLayer01    = 100;
$topLayer01_a  = 200;
$topLayer02    = 300;
$topLayer02_a  = 400;

$hGap          = 25;
$width         = 150;

$height        = 100;
$left          = 25;

$kpiLeft       = 55;
$kpi_ab_Left   = 15;
$kpi_ab_Top    = 25;

$xAxisFontSize = 6;
$yAxisFontSize = 6;



$graphBgColor = "#ccccff";


$box_01                         =  new kpiBox;
    $box_01->title              = "KPI 01a";
    $box_01->left               =  $left;
    $box_01->top                =  $topLayer01;
    $box_01->width              =  $width;
    $box_01->height             =  $height;
    $box_01->kpiTop             =  40;
    $box_01->kpiLeft            =  $kpiLeft;
    $box_01->kpiVal             =  25;
    $box_01->kpiTarget          =  10;
    $box_01->kpiRedBelowTarget  =  true;
    $box_01->kpiTargetWidth     =  30;
    $box_01->kpiTargetHeight    =  30;
    $box_01->kpiTargetLeft      =  5;
    $box_01->kpiTargetTop       =  5;
    $box_01->sqlAct             = "SELECT [val] FROM dbTest.dbo.kpi       where kpi = '1'";
    $box_01->sqlTrg             = "SELECT [val] FROM dbTest.dbo.kpiTarget where kpi = '1'";
$box_01->draw();

$box_01_a                       =  new kpiBox;
    $box_01_a->title              = "KPI 01_a";
    $box_01_a->left               =  $left;
    $box_01_a->top                =  $topLayer01_a;
    $box_01_a->width              =  $width * 0.5;
    $box_01_a->height             =  $height * 0.5;
    $box_01_a->kpiTop             =  $kpi_ab_Top;
    $box_01_a->kpiLeft            =  $kpi_ab_Left;
    $box_01_a->kpiVal             =  10;
    $box_01_a->kpiTarget          =  25;
    $box_01_a->kpiRedBelowTarget  =  true;
    $box_01_a->kpiTargetWidth     =  30;
    $box_01_a->kpiTargetHeight    =  30;
    $box_01_a->kpiTargetLeft      =  5;
    $box_01_a->kpiTargetTop       =  5;    
    $box_01_a->sqlAct             = "SELECT [val] FROM dbTest.dbo.kpi       where kpi = '1a'";
    $box_01_a->sqlTrg             = "SELECT [val] FROM dbTest.dbo.kpiTarget where kpi = '1a'";

$box_01_a->draw();

$box_01_b                       =  new kpiBox;
    $box_01_b->title              = "KPI 01_b";
    $box_01_b->left               =  $left + ( $width * 0.5 ); 
    $box_01_b->top                =  $topLayer01_a;
    $box_01_b->width              =  $width * 0.5;
    $box_01_b->height             =  $height * 0.5;
    $box_01_b->kpiTop             =  $kpi_ab_Top;
    $box_01_b->kpiLeft            =  $kpi_ab_Left;
    $box_01_b->kpiVal             =  25;
    $box_01_b->kpiTarget          =  10;
    $box_01_b->kpiRedBelowTarget  =  true;
    $box_01_b->kpiTargetWidth     =  30;
    $box_01_b->kpiTargetHeight    =  30;
    $box_01_b->kpiTargetLeft      =  5;
    $box_01_b->kpiTargetTop       =  5;
    $box_01_b->sqlAct             = "SELECT [val] FROM dbTest.dbo.kpi       where kpi = '1b'";
    $box_01_b->sqlTrg             = "SELECT [val] FROM dbTest.dbo.kpiTarget where kpi = '1b'";
$box_01_b->draw();





$box_02                         = new kpiBox;
    $box_02->title              = "KPI 02";
    $box_02->left               = $left +  $width + $hGap ;
    $box_02->top                = $topLayer01;
    $box_02->width              = $width;
    $box_02->height             = $height;
    $box_02->kpiTop             =      40;
    $box_02->kpiLeft            = $kpiLeft;
    $box_02->kpiVal             =      90;
    $box_02->kpiTarget          =      15;
    $box_02->kpiRedBelowTarget  =    false;
    $box_02->kpiTargetWidth     =      30;
    $box_02->kpiTargetHeight    =      30;
    $box_02->kpiTargetLeft      =       5;
    $box_02->kpiTargetTop       =       5;
    $box_02->sqlAct             = "SELECT [val] FROM dbTest.dbo.kpi       where kpi = '2'";
    $box_02->sqlTrg             = "SELECT [val] FROM dbTest.dbo.kpiTarget where kpi = '2'";
$box_02->draw();

$box_02_a                       =  new kpiBox;
    $box_02_a->title              = "KPI 02_a";
    $box_02_a->left               =  $left +  $width + $hGap ;
    $box_02_a->top                =  $topLayer01_a;
    $box_02_a->width              =  $width * 0.5;
    $box_02_a->height             =  $height * 0.5;
    $box_02_a->kpiTop             =  $kpi_ab_Top;
    $box_02_a->kpiLeft            =  $kpi_ab_Left;
    $box_02_a->kpiVal             =  10;
    $box_02_a->kpiTarget          =  25;
    $box_02_a->kpiRedBelowTarget  =  true;
    $box_02_a->kpiTargetWidth     =  30;
    $box_02_a->kpiTargetHeight    =  30;
    $box_02_a->kpiTargetLeft      =  5;
    $box_02_a->kpiTargetTop       =  5;
    $box_02_a->sqlAct             = "SELECT [val] FROM dbTest.dbo.kpi       where kpi = '2a'";
    $box_02_a->sqlTrg             = "SELECT [val] FROM dbTest.dbo.kpiTarget where kpi = '2a'";
$box_02_a->draw();

$box_02_b                       =  new kpiBox;
    $box_02_b->title              = "KPI 02_b";
    $box_02_b->left               =  $left +  $width + $hGap + ( $width * 0.5 ); 
    $box_02_b->top                =  $topLayer01_a;
    $box_02_b->width              =  $width * 0.5;
    $box_02_b->height             =  $height * 0.5;
    $box_02_b->kpiTop             =  $kpi_ab_Top;
    $box_02_b->kpiLeft            =  $kpi_ab_Left;
    $box_02_b->kpiVal             =  25;
    $box_02_b->kpiTarget          =  10;
    $box_02_b->kpiRedBelowTarget  =  true;
    $box_02_b->kpiTargetWidth     =  30;
    $box_02_b->kpiTargetHeight    =  30;
    $box_02_b->kpiTargetLeft      =  5;
    $box_02_b->kpiTargetTop       =  5;
    $box_02_b->sqlAct             = "SELECT [val] FROM dbTest.dbo.kpi       where kpi = '2b'";
    $box_02_b->sqlTrg             = "SELECT [val] FROM dbTest.dbo.kpiTarget where kpi = '2b'";    
$box_02_b->draw();





$box_03                         = new kpiBox ;
    $box_03->title              = "KPI 03" ;
    $box_03->left               = $left + 2 * ($width + $hGap) ;
    $box_03->top                = $topLayer01 ;
    $box_03->width              = $width ;
    $box_03->height             = $height ;
    $box_03->kpiTop             =      40;
    $box_03->kpiLeft            = $kpiLeft;
    $box_03->kpiVal             =      80;
    $box_03->kpiTarget          =      95;
    $box_03->kpiRedBelowTarget  =    true;
    $box_03->kpiTargetWidth     =      30;
    $box_03->kpiTargetHeight    =      30;
    $box_03->kpiTargetLeft      =       5;
    $box_03->kpiTargetTop       =       5;
    $box_03->sqlAct             = "SELECT [val] FROM dbTest.dbo.kpi       where kpi = '3'";
    $box_03->sqlTrg             = "SELECT [val] FROM dbTest.dbo.kpiTarget where kpi = '3'";

$box_03->draw();

$box_03_a                       =  new kpiBox;
    $box_03_a->title              = "KPI 03_a";
    $box_03_a->left               =  $left +  2 * ( $width + $hGap ) ;
    $box_03_a->top                =  $topLayer01_a;
    $box_03_a->width              =  $width * 0.5;
    $box_03_a->height             =  $height * 0.5;
    $box_03_a->kpiTop             =  $kpi_ab_Top;
    $box_03_a->kpiLeft            =  $kpi_ab_Left;
    $box_03_a->kpiVal             =  10;
    $box_03_a->kpiTarget          =  25;
    $box_03_a->kpiRedBelowTarget  =  true;
    $box_03_a->kpiTargetWidth     =  30;
    $box_03_a->kpiTargetHeight    =  30;
    $box_03_a->kpiTargetLeft      =  5;
    $box_03_a->kpiTargetTop       =  5;
    $box_03_a->sqlAct             = "SELECT [val] FROM dbTest.dbo.kpi       where kpi = '3a'";
    $box_03_a->sqlTrg             = "SELECT [val] FROM dbTest.dbo.kpiTarget where kpi = '3a'";    
$box_03_a->draw();

$box_03_b                       =  new kpiBox;
    $box_03_b->title              = "KPI 03_b";
    $box_03_b->left               =  $left +  2 * ( $width + $hGap ) + ( $width * 0.5 ); 
    $box_03_b->top                =  $topLayer01_a;
    $box_03_b->width              =  $width * 0.5;
    $box_03_b->height             =  $height * 0.5;
    $box_03_b->kpiTop             =  $kpi_ab_Top;
    $box_03_b->kpiLeft            =  $kpi_ab_Left;
    $box_03_b->kpiVal             =  25;
    $box_03_b->kpiTarget          =  10;
    $box_03_b->kpiRedBelowTarget  =  true;
    $box_03_b->kpiTargetWidth     =  30;
    $box_03_b->kpiTargetHeight    =  30;
    $box_03_b->kpiTargetLeft      =  5;
    $box_03_b->kpiTargetTop       =  5;
    $box_03_b->sqlAct             = "SELECT [val] FROM dbTest.dbo.kpi       where kpi = '3b'";
    $box_03_b->sqlTrg             = "SELECT [val] FROM dbTest.dbo.kpiTarget where kpi = '3b'";    
$box_03_b->draw();




$box_04                         = new kpiBox;
    $box_04->title              ="KPI 04";
    $box_04->left               = $left + 3 * ($width + $hGap) ;
    $box_04->top                = $topLayer01 ;
    $box_04->width              = $width ;
    $box_04->height             = $height ;
    $box_04->kpiTop             =      40;
    $box_04->kpiLeft            = $kpiLeft;
    $box_04->kpiVal             =     100;
    $box_04->kpiTarget          =      95;
    $box_04->kpiRedBelowTarget  =    true;
    $box_04->kpiTargetWidth     =      30;
    $box_04->kpiTargetHeight    =      30;
    $box_04->kpiTargetLeft      =       5;
    $box_04->kpiTargetTop       =       5;
    $box_04->sqlAct             = "SELECT [val] FROM dbTest.dbo.kpi       where kpi = '4'";
    $box_04->sqlTrg             = "SELECT [val] FROM dbTest.dbo.kpiTarget where kpi = '4'";
$box_04->draw();

$box_04_a                       =  new kpiBox;
    $box_04_a->title              = "KPI 04_a";
    $box_04_a->left               =  $left +  3 * ( $width + $hGap ) ;
    $box_04_a->top                =  $topLayer01_a;
    $box_04_a->width              =  $width * 0.5;
    $box_04_a->height             =  $height * 0.5;
    $box_04_a->kpiTop             =  $kpi_ab_Top;
    $box_04_a->kpiLeft            =  $kpi_ab_Left;
    $box_04_a->kpiVal             =  10;
    $box_04_a->kpiTarget          =  25;
    $box_04_a->kpiRedBelowTarget  =  true;
    $box_04_a->kpiTargetWidth     =  30;
    $box_04_a->kpiTargetHeight    =  30;
    $box_04_a->kpiTargetLeft      =  5;
    $box_04_a->kpiTargetTop       =  5;
    $box_04_a->sqlAct             = "SELECT [val] FROM dbTest.dbo.kpi       where kpi = '4a'";
    $box_04_a->sqlTrg             = "SELECT [val] FROM dbTest.dbo.kpiTarget where kpi = '4a'";    
$box_04_a->draw();

$box_04_b                       =  new kpiBox;
    $box_04_b->title              = "KPI 04_b";
    $box_04_b->left               =  $left +  3 * ( $width + $hGap ) + ( $width * 0.5 ); 
    $box_04_b->top                =  $topLayer01_a;
    $box_04_b->width              =  $width * 0.5;
    $box_04_b->height             =  $height * 0.5;
    $box_04_b->kpiTop             =  $kpi_ab_Top;
    $box_04_b->kpiLeft            =  $kpi_ab_Left;
    $box_04_b->kpiVal             =  25;
    $box_04_b->kpiTarget          =  10;
    $box_04_b->kpiRedBelowTarget  =  true;
    $box_04_b->kpiTargetWidth     =  30;
    $box_04_b->kpiTargetHeight    =  30;
    $box_04_b->kpiTargetLeft      =  5;
    $box_04_b->kpiTargetTop       =  5;
    $box_04_b->sqlAct             = "SELECT [val] FROM dbTest.dbo.kpi       where kpi = '4b'";
    $box_04_b->sqlTrg             = "SELECT [val] FROM dbTest.dbo.kpiTarget where kpi = '4b'";    
$box_04_b->draw();





$box_05                         = new kpiBox ;
    $box_05->title              = "KPI 05" ;
    $box_05->left               = $left + 4 * ($width + $hGap) ;
    $box_05->top                = $topLayer01 ;
    $box_05->width              = $width ;
    $box_05->height             = $height ;
    $box_05->kpiTop             =      40;
    $box_05->kpiLeft            = $kpiLeft;
    $box_05->kpiVal             =       9;
    $box_05->kpiTarget          =       1;
    $box_05->kpiRedBelowTarget  =    false;
    $box_05->kpiTargetWidth     =      30;
    $box_05->kpiTargetHeight    =      30;
    $box_05->kpiTargetLeft      =       5;
    $box_05->kpiTargetTop       =       5;
    $box_05->sqlAct             = "SELECT [val] FROM dbTest.dbo.kpi       where kpi = '5'";
    $box_05->sqlTrg             = "SELECT [val] FROM dbTest.dbo.kpiTarget where kpi = '5'";
$box_05->draw();

$box_05_a                       =  new kpiBox;
    $box_05_a->title              = "KPI 05_a";
    $box_05_a->left               =  $left + 4 * ( $width + $hGap ) ;
    $box_05_a->top                =  $topLayer01_a;
    $box_05_a->width              =  $width * 0.5;
    $box_05_a->height             =  $height * 0.5;
    $box_05_a->kpiTop             =  $kpi_ab_Top;
    $box_05_a->kpiLeft            =  $kpi_ab_Left;
    $box_05_a->kpiVal             =  10;
    $box_05_a->kpiTarget          =  25;
    $box_05_a->kpiRedBelowTarget  =  true;
    $box_05_a->kpiTargetWidth     =  30;
    $box_05_a->kpiTargetHeight    =  30;
    $box_05_a->kpiTargetLeft      =  5;
    $box_05_a->kpiTargetTop       =  5;
    $box_05_a->sqlAct             = "SELECT [val] FROM dbTest.dbo.kpi       where kpi = '5a'";
    $box_05_a->sqlTrg             = "SELECT [val] FROM dbTest.dbo.kpiTarget where kpi = '5a'";    
$box_05_a->draw();

$box_05_b                       =  new kpiBox;
    $box_05_b->title              = "KPI 04_b";
    $box_05_b->left               =  $left +  4 * ( $width + $hGap ) + ( $width * 0.5 ); 
    $box_05_b->top                =  $topLayer01_a;
    $box_05_b->width              =  $width * 0.5;
    $box_05_b->height             =  $height * 0.5;
    $box_05_b->kpiTop             =  $kpi_ab_Top;
    $box_05_b->kpiLeft            =  $kpi_ab_Left;
    $box_05_b->kpiVal             =  25;
    $box_05_b->kpiTarget          =  10;
    $box_05_b->kpiRedBelowTarget  =  true;
    $box_05_b->kpiTargetWidth     =  30;
    $box_05_b->kpiTargetHeight    =  30;
    $box_05_b->kpiTargetLeft      =  5;
    $box_05_b->kpiTargetTop       =  5;
    $box_05_b->sqlAct             = "SELECT [val] FROM dbTest.dbo.kpi       where kpi = '5b'";
    $box_05_b->sqlTrg             = "SELECT [val] FROM dbTest.dbo.kpiTarget where kpi = '5b'";    
$box_05_b->draw();



$barGraph_01                          = new barGraph ;
    $barGraph_01->id                  =  "G_1" ;
    $barGraph_01->title               =  "G_1" ;
    $barGraph_01->titleFontSize       =     12 ;
    $barGraph_01->titleLeftToRightPos =    0.5 ;
    $barGraph_01->titleTopToBottomPos =   0.95 ;    
    $barGraph_01->legendText          =  "New" ;
    $barGraph_01->legendShow          = "false" ;
    $barGraph_01->left                = $left ;
    $barGraph_01->top                 = $topLayer02 ;
    $barGraph_01->width               = $width ;
    $barGraph_01->height              = $height * 1.5 ;
    $barGraph_01->xCsv                = "'cats', 'dogs', 'fish', 'Xcats', 'Xdogs', 'Xfish' ";
    $barGraph_01->yCsv                = "    10,      2,      3,     10,      2,       3";
    $barGraph_01->color               =  "yellow";
    $barGraph_01->bgColor             = $graphBgColor;
$barGraph_01->draw();



$barGraph_02                          = new barGraph;
    $barGraph_02->id                  =  "G_2";
    $barGraph_02->title               =  "G_2";
    $barGraph_02->titleFontSize       =     12;
    $barGraph_02->titleLeftToRightPos =    0.5;
    $barGraph_02->titleTopToBottomPos =   0.95;    
    $barGraph_02->legendText          =    "2";
    $barGraph_02->legendShow          = "false";
    $barGraph_02->left                = $left + $hGap + $width;
    $barGraph_02->top                 = $topLayer02;
    $barGraph_02->width               = $width;
    $barGraph_02->height              = $height * 1.5 ;
    $barGraph_02->xCsv                = "'cats', 'dogs', 'fish'";
    $barGraph_02->yCsv                = "    10,      2,      3";
    $barGraph_02->color               =  "orange";
    $barGraph_02->bgColor             = $graphBgColor;
$barGraph_02->draw();



$barGraph_03                          = new barGraph;
    $barGraph_03->id                  =  "G_3";
    $barGraph_03->title               =  "G_3";
    $barGraph_03->titleFontSize       =     12;
    $barGraph_03->titleLeftToRightPos =    0.5;
    $barGraph_03->titleTopToBottomPos =   0.95;    
    $barGraph_03->legendText          =    "3";
    $barGraph_03->legendShow          = "false";
    $barGraph_03->left                = $left + 2 * ( $hGap + $width );
    $barGraph_03->top                 = $topLayer02;
    $barGraph_03->width               = $width;
    $barGraph_03->height              = $height * 1.5 ;
    $barGraph_03->xCsv                = "'cats', 'dogs', 'fish'";
    $barGraph_03->yCsv                = "    10,      2,      3";
    $barGraph_03->color               =  "green";
    $barGraph_03->bgColor             = $graphBgColor;
$barGraph_03->draw();



$barGraph_04                          = new barGraph;
    $barGraph_04->id                  =  "G_4";
    $barGraph_04->title               =  "G_4";
    $barGraph_04->titleFontSize       =     12;
    $barGraph_04->titleLeftToRightPos =    0.5;
    $barGraph_04->titleTopToBottomPos =   0.95;    
    $barGraph_04->legendText          =    "4";
    $barGraph_04->legendShow          = "false";
    $barGraph_04->left                = $left + 3 * ( $hGap + $width );
    $barGraph_04->top                 = $topLayer02;
    $barGraph_04->width               = $width;
    $barGraph_04->height              = $height * 1.5 ;
    $barGraph_04->xCsv                = "'cats', 'dogs', 'fish'";
    $barGraph_04->yCsv                = "    10,      2,      3";
    $barGraph_04->color               =  "blue";
    $barGraph_04->bgColor             = $graphBgColor;
$barGraph_04->draw();



$barGraph_05                          = new barGraph;
    $barGraph_05->id                  =  "G_5";
    $barGraph_05->title               =  "G_5";
    $barGraph_05->titleFontSize       =     12;
    $barGraph_05->titleLeftToRightPos =    0.5;
    $barGraph_05->titleTopToBottomPos =   0.95;    
    $barGraph_05->legendText          =    "5";
    $barGraph_05->legendShow          = "false";
    $barGraph_05->left                = $left + 4 * ( $hGap + $width );
    $barGraph_05->top                 = $topLayer02;
    $barGraph_05->width               = $width;
    $barGraph_05->height              = $height * 1.5;
    $barGraph_05->xCsv                = "1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31";
    $barGraph_05->yCsv                = "1,2,3,4,5,6,7,8,9,10,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0";
    $barGraph_05->color               =  "red";
    $barGraph_05->bgColor             = $graphBgColor;
    $barGraph_05->xAxisFontSize       = $xAxisFontSize;
    $barGraph_05->yAxisFontSize       = $yAxisFontSize;
$barGraph_05->draw();


?>



</body>
</html>