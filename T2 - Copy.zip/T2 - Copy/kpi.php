<?php

class kpiBox {
    
    public $title     = "";
    public $titleSize = 10;

    public $sqlAct    = "";
    public $sqlTrg    = "";

    public $left      = 0; 
    public $top       = 0;
    public $width     = 0;
    public $height    = 0;
    
    public $kpiVal    = 0;        
    public $kpiLeft   = 0; 
    public $kpiTop    = 0;

    public $kpiTarget          = 0;
    public $kpiRedBelowTarget  = true;
    public $kpiTargetWidth     = 0;
    public $kpiTargetHeight    = 0;
    public $kpiTargetLeft      = 0;
    public $kpiTargetTop       = 0;





    function getSqlValAct() {
        if ( getSQLOpen( $this->sqlAct ) ) {
            While ( $row = sqlsrv_fetch_array( $GLOBALS['stmt'], SQLSRV_FETCH_NUMERIC )) {
                $val = $row[ 0 ];  
                getSQLClose();
                return $val;
            }
        }
    }
    

    function getSqlValTrg() {
        if ( getSQLOpen( $this->sqlTrg ) ) {
            While ( $row = sqlsrv_fetch_array( $GLOBALS['stmt'], SQLSRV_FETCH_NUMERIC )) {
                $val = $row[ 0 ];  
                getSQLClose();
                return $val;
            }
        }
    }




    function kpiColor () {
        if ( $this->kpiVal >= $this->kpiTarget ) {
            if ( $this->kpiRedBelowTarget )  { return "green";} else { return "red";}
        } else {
            if ( $this->kpiRedBelowTarget )  { return "red";  } else { return "green";}
        }
    }


    function draw () {
        
        if ( $this->sqlAct != "" ) {
            $this->kpiVal = $this->getSqlValAct();
        }

        if ( $this->sqlTrg != "" ) {
            $this->kpiTarget = $this->getSqlValTrg();
        }

        $style =          "position:absolute; z-index:1; ";
        $style = $style . "background-color:" . $this->kpiColor() . ";";
        $style = $style . "left:"   . $this->left   . "px;";
        $style = $style . "top:"    . $this->top    . "px;";
        $style = $style . "width:"  . $this->width  . "px;";
        $style = $style . "height:" . $this->height . "px;";
        $style = $style . "height:" . $this->height . "px;";

        $kpiStyle  =             "position:absolute; color:white; ";
        $kpiStyle  = $kpiStyle . "left:" . $this->kpiLeft . "px;";
        $kpiStyle  = $kpiStyle . "top:"  . $this->kpiTop  . "px;";

        $targetBoxStyle  =                  "position:relative; background-color:white; ";
        $targetBoxStyle  = $targetBoxStyle . "width:"  . $this->kpiTargetWidth  . "px;";
        $targetBoxStyle  = $targetBoxStyle . "height:" . $this->kpiTargetHeight . "px;";
        $targetBoxStyle  = $targetBoxStyle . "left:"   . $this->targetLeft()    . "px;";
        $targetBoxStyle  = $targetBoxStyle . "top:"    . $this->targetTop()     . "px;";
        

        $targetStyle =  "position:relative; ";
        $targetStyle  = $targetStyle . "left:" . $this->kpiTargetLeft . "px;";
        $targetStyle  = $targetStyle . "top:"  . $this->kpiTargetTop  . "px;";

        echo "<div style=\""      . $style          . "\">";
        echo "  <span style=\"position:absolute; color:lightgrey; padding-left:3px; padding-top:3px;
                            font-size:" . $this->titleSize . ";\">" 
                                                            . $this->title     . "</span>";
        echo "  <span style=\""   . $kpiStyle       . "\">" . $this->kpiVal    . "</span>";
        echo "  <div style=\""    . $targetBoxStyle . "\">";
        echo "    <span style=\"" . $targetStyle    . "\">" . $this->kpiTarget . "</span>";
        echo "  </div>";
        echo "</div>";
    
    }   

    function targetLeft() {
        return $this->width - $this->kpiTargetWidth - 1 ;
    }

    function targetTop() {
        return $this->height - $this->kpiTargetHeight -1 ;
    }
}


?>

