<html>
<head>
  <script src="https://cdn.plot.ly/plotly-latest.min.js"></script>
</head>
<body>

<?php

include_once("kpi.php");
include_once("barGraph.php");

$box_01                         = new kpiBox;
    $box_01->title              ="KPI 01";
    $box_01->left               =     100;
    $box_01->top                =      66;
    $box_01->width              =     100;
    $box_01->height             =     100;
    $box_01->kpiTop             =      40;
    $box_01->kpiLeft            =      38;
    $box_01->kpiVal             =      25;
    $box_01->kpiTarget          =      10;
    $box_01->kpiRedBelowTarget  =    true;
    $box_01->kpiTargetWidth     =      30;
    $box_01->kpiTargetHeight    =      30;
    $box_01->kpiTargetLeft      =       5;
    $box_01->kpiTargetTop       =       5;
$box_01->draw();

$box_02                         = new kpiBox;
    $box_02->title              ="KPI 02";
    $box_02->left               =     220;
    $box_02->top                =      66;
    $box_02->width              =     100;
    $box_02->height             =     100;
    $box_02->kpiTop             =      40;
    $box_02->kpiLeft            =      38;
    $box_02->kpiVal             =      90;
    $box_02->kpiTarget          =      15;
    $box_02->kpiRedBelowTarget  =    false;
    $box_02->kpiTargetWidth     =      30;
    $box_02->kpiTargetHeight    =      30;
    $box_02->kpiTargetLeft      =       5;
    $box_02->kpiTargetTop       =       5;
$box_02->draw();

$box_03                         = new kpiBox;
    $box_03->title              ="KPI 03";
    $box_03->left               =     340;
    $box_03->top                =      66;
    $box_03->width              =     100;
    $box_03->height             =     100;
    $box_03->kpiTop             =      40;
    $box_03->kpiLeft            =      38;
    $box_03->kpiVal             =      80;
    $box_03->kpiTarget          =      95;
    $box_03->kpiRedBelowTarget  =    true;
    $box_03->kpiTargetWidth     =      30;
    $box_03->kpiTargetHeight    =      30;
    $box_03->kpiTargetLeft      =       5;
    $box_03->kpiTargetTop       =       5;
$box_03->draw();

$box_04                         = new kpiBox;
    $box_04->title              ="KPI 04";
    $box_04->left               =     460;
    $box_04->top                =      66;
    $box_04->width              =     100;
    $box_04->height             =     100;
    $box_04->kpiTop             =      40;
    $box_04->kpiLeft            =      38;
    $box_04->kpiVal             =     100;
    $box_04->kpiTarget          =      95;
    $box_04->kpiRedBelowTarget  =    true;
    $box_04->kpiTargetWidth     =      30;
    $box_04->kpiTargetHeight    =      30;
    $box_04->kpiTargetLeft      =       5;
    $box_04->kpiTargetTop       =       5;
$box_04->draw();

$box_05                         = new kpiBox;
    $box_05->title              ="KPI 05";
    $box_05->left               =     580;
    $box_05->top                =      66;
    $box_05->width              =     100;
    $box_05->height             =     100;
    $box_05->kpiTop             =      40;
    $box_05->kpiLeft            =      38;
    $box_05->kpiVal             =       9;
    $box_05->kpiTarget          =       1;
    $box_05->kpiRedBelowTarget  =    false;
    $box_05->kpiTargetWidth     =      30;
    $box_05->kpiTargetHeight    =      30;
    $box_05->kpiTargetLeft      =       5;
    $box_05->kpiTargetTop       =       5;
$box_05->draw();



$barGraph_01                          = new barGraph;
    $barGraph_01->id                  =  "G_1";
    $barGraph_01->title               =  "G_1";
    $barGraph_01->titleFontSize       =     12;
    $barGraph_01->titleLeftToRightPos =    0.5;
    $barGraph_01->titleTopToBottomPos =   0.95;    
    $barGraph_01->legendText          =  "New";
    $barGraph_01->legendShow          = "false";
    $barGraph_01->left                =    100;
    $barGraph_01->top                 =    180;
    $barGraph_01->width               =    100;
    $barGraph_01->height              =    100;
    $barGraph_01->xCsv                = "'cats', 'dogs', 'fish', 'Xcats', 'Xdogs', 'Xfish' ";
    $barGraph_01->yCsv                = "    10,      2,      3,     10,      2,       3";
    $barGraph_01->color               =  "yellow";
    $barGraph_01->bgColor             = "#0101FF";
$barGraph_01->draw();



$barGraph_02                          = new barGraph;
    $barGraph_02->id                  =  "G_2";
    $barGraph_02->title               =  "G_2";
    $barGraph_02->titleFontSize       =     12;
    $barGraph_02->titleLeftToRightPos =    0.5;
    $barGraph_02->titleTopToBottomPos =   0.95;    
    $barGraph_02->legendText          =    "2";
    $barGraph_02->legendShow          = "false";
    $barGraph_02->left                =    220;
    $barGraph_02->top                 =    180;
    $barGraph_02->width               =    100;
    $barGraph_02->height              =    100;
    $barGraph_02->xCsv                = "'cats', 'dogs', 'fish'";
    $barGraph_02->yCsv                = "    10,      2,      3";
    $barGraph_02->color               =  "green";
    $barGraph_02->bgColor             = "#0202FF";
$barGraph_02->draw();



$barGraph_03                          = new barGraph;
    $barGraph_03->id                  =  "G_3";
    $barGraph_03->title               =  "G_3";
    $barGraph_03->titleFontSize       =     12;
    $barGraph_03->titleLeftToRightPos =    0.5;
    $barGraph_03->titleTopToBottomPos =   0.95;    
    $barGraph_03->legendText          =    "3";
    $barGraph_03->legendShow          = "false";
    $barGraph_03->left                =    340;
    $barGraph_03->top                 =    180;
    $barGraph_03->width               =    100;
    $barGraph_03->height              =    100;
    $barGraph_03->xCsv                = "'cats', 'dogs', 'fish'";
    $barGraph_03->yCsv                = "    10,      2,      3";
    $barGraph_03->color               =  "green";
    $barGraph_03->bgColor             = "#0303FF";
$barGraph_03->draw();



$barGraph_04                          = new barGraph;
    $barGraph_04->id                  =  "G_4";
    $barGraph_04->title               =  "G_4";
    $barGraph_04->titleFontSize       =     12;
    $barGraph_04->titleLeftToRightPos =    0.5;
    $barGraph_04->titleTopToBottomPos =   0.95;    
    $barGraph_04->legendText          =    "4";
    $barGraph_04->legendShow          = "false";
    $barGraph_04->left                =    460;
    $barGraph_04->top                 =    180;
    $barGraph_04->width               =    100;
    $barGraph_04->height              =    100;
    $barGraph_04->xCsv                = "'cats', 'dogs', 'fish'";
    $barGraph_04->yCsv                = "    10,      2,      3";
    $barGraph_04->color               =  "green";
    $barGraph_04->bgColor             = "#0404FF";
$barGraph_04->draw();



$barGraph_05                          = new barGraph;
    $barGraph_05->id                  =  "G_5";
    $barGraph_05->title               =  "G_5";
    $barGraph_05->titleFontSize       =     12;
    $barGraph_05->titleLeftToRightPos =    0.5;
    $barGraph_05->titleTopToBottomPos =   0.95;    
    $barGraph_05->legendText          =    "5";
    $barGraph_05->legendShow          = "false";
    $barGraph_05->left                =    580;
    $barGraph_05->top                 =    180;
    $barGraph_05->width               =    100;
    $barGraph_05->height              =    100;
    $barGraph_05->xCsv                = "'cats', 'dogs', 'fish'";
    $barGraph_05->yCsv                = "    10,      2,      3";
    $barGraph_05->color               =  "green";
    $barGraph_05->bgColor             = "#0505FF";
$barGraph_05->draw();


?>



</body>
</html>