<?php 

function loadGlobals() {

  $GLOBALS[ 'serverName' ] = "SERVER";
  $GLOBALS[ 'UID' ]        = "UID";
  $GLOBALS[ 'PWD' ]        = "password";
  $GLOBALS[ 'Database' ]   = "dbName";

}

function getSQLOpen( $sql ) {  

    $GLOBALS[ 'connection' ] = array( "UID"      => $GLOBALS[ 'UID' ], 
                                      "PWD"      => $GLOBALS[ 'PWD' ], 
                                      "Database" => $GLOBALS[ 'Database' ]);        

    $GLOBALS[ 'conn' ] = sqlsrv_connect( $GLOBALS[ 'serverName' ] ,  
                                         $GLOBALS[ 'connection' ]);

    /// CHECK CONNECTION IS OK
    if ( $GLOBALS[ 'conn' ] === false ) {
        echo "error!";
        die( print_r( sqlsrv_errors(), true ) );
        return false;  
    }
    else
    {        
        $GLOBALS[ 'stmt'    ] = sqlsrv_query(          $GLOBALS['conn'], $sql );	  		  		  	    
        $GLOBALS[ 'fld_cnt' ] = sqlsrv_num_fields(     $GLOBALS['stmt']       );
        $GLOBALS[ 'fld_dta' ] = sqlsrv_field_metadata( $GLOBALS['stmt']       );
    return true; 		  
    }
}

function getSQLClose() {
   sqlsrv_free_stmt( $GLOBALS[ 'stmt' ] );                
   sqlsrv_close(     $GLOBALS[ 'conn' ] );       
}

loadGlobals();

?>